-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 27-Nov-2018 às 18:24
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `estoque`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE `admin` (
  `idadmin` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `admin`
--

INSERT INTO `admin` (`idadmin`, `usuario`, `senha`, `image`) VALUES
(1, 'Cristiano', 'cristiano', 'bbad900e63b410d0e85bfa715b2f49d0.gif'),
(2, 'Joseniltom', 'joseniltom', '77485cd6f1a72c981a46fa9527f38f60.gif');

-- --------------------------------------------------------

--
-- Estrutura da tabela `alocacao`
--

CREATE TABLE `alocacao` (
  `idalocacao` int(11) NOT NULL,
  `ferramenta` varchar(100) NOT NULL,
  `qnt` int(11) NOT NULL,
  `sigla` varchar(10) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `data_saida` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `empresa` varchar(100) NOT NULL,
  `setor` varchar(100) NOT NULL,
  `status_saida` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ferramenta`
--

CREATE TABLE `ferramenta` (
  `idferramenta` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `qnt` int(11) NOT NULL,
  `sigla` varchar(10) NOT NULL,
  `situacao` int(1) NOT NULL,
  `status_saida` varchar(100) NOT NULL,
  `view` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `ferramenta`
--

INSERT INTO `ferramenta` (`idferramenta`, `nome`, `qnt`, `sigla`, `situacao`, `status_saida`, `view`) VALUES
(10, 'Martelo', 5, 'Und', 0, 'Funcionando', 1),
(11, 'jiboia', 11, 'M', 0, 'Funcionando', 2),
(12, 'girino', 155, 'Und', 0, 'Funcionando', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `historico`
--

CREATE TABLE `historico` (
  `idalocacao` int(11) NOT NULL,
  `ferramenta` varchar(255) NOT NULL,
  `qnt` int(11) NOT NULL,
  `sigla` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `data_saida` datetime NOT NULL,
  `empresa` varchar(255) NOT NULL,
  `setor` varchar(255) NOT NULL,
  `status_saida` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `historico`
--

INSERT INTO `historico` (`idalocacao`, `ferramenta`, `qnt`, `sigla`, `usuario`, `data_saida`, `empresa`, `setor`, `status_saida`) VALUES
(1, 'girino', 150, 'Und', 'Eronaldo Peixoto de Aquino ', '0000-00-00 00:00:00', 'Brisanet', 'ConstruÃ§Ã£o', 'Funcionando'),
(2, 'jiboia', 5, 'M', 'Luis Gustavo Souza Maciel ', '0000-00-00 00:00:00', 'Nossa Fruta', 'Cozinha', 'Funcionando'),
(3, 'Martelo', 2, 'Und', 'Eronaldo Peixoto de Aquino ', '0000-00-00 00:00:00', 'Brisanet', 'ConstruÃ§Ã£o', 'Funcionando'),
(4, 'jiboia', 8, 'M', '', '0000-00-00 00:00:00', '', '', 'Funcionando');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `empresa` varchar(100) NOT NULL,
  `setor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `nome`, `empresa`, `setor`) VALUES
(1, 'Eronaldo Peixoto de Aquino ', 'Brisanet', 'ConstruÃ§Ã£o'),
(2, 'Luis Gustavo Souza Maciel ', 'Nossa Fruta', 'Cozinha'),
(3, 'Josimar Martins Pereira Junior', 'AgriTech', 'Agoador'),
(4, 'Josenildo Henrique Gurgel de Almeida', 'AgriTech', 'Engenharia'),
(5, 'Cristiano Benevides', 'AgriTech', 'GestÃ£o');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idadmin`);

--
-- Indexes for table `alocacao`
--
ALTER TABLE `alocacao`
  ADD PRIMARY KEY (`idalocacao`);

--
-- Indexes for table `ferramenta`
--
ALTER TABLE `ferramenta`
  ADD PRIMARY KEY (`idferramenta`);

--
-- Indexes for table `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`idalocacao`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `idadmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `alocacao`
--
ALTER TABLE `alocacao`
  MODIFY `idalocacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `ferramenta`
--
ALTER TABLE `ferramenta`
  MODIFY `idferramenta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `historico`
--
ALTER TABLE `historico`
  MODIFY `idalocacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
